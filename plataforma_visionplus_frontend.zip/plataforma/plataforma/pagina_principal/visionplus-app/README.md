# Proyecto Plataforma de Entretenimiento

En este proyecto aprenderemos a realizar una plataforma de entretenimiento desde 0.

## Tecnologías

Este proyecto fue inicializado con React y Vite.

- [@vitejs/plugin-react](https://github.com/vitejs/vite-plugin-react/blob/main/packages/plugin-react)
- [@vitejs/plugin-react-swc](https://swc.rs/)